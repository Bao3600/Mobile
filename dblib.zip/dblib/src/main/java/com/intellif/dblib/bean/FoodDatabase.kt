package com.intellif.dblib.bean

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


/**
 * Created by wei.
 * Date: 2020/9/22 下午2:59
 * Description:
 */
@Database(entities = [Food::class], version = 1, exportSchema = false)
abstract class FoodDatabase : RoomDatabase() {
    abstract fun getFoodDao(): FoodDao

    companion object {
        private const val DB_NAME = "FoodDatabase.db"

        @Volatile
        private var instance: FoodDatabase?=null

        @Synchronized
        fun getInstance(context: Context): FoodDatabase {
            if (instance == null) {
                instance = create(context)
            }
            return instance!!
        }

        private fun create(context: Context): FoodDatabase {
            return Room.databaseBuilder(
                context,
                FoodDatabase::class.java,
                DB_NAME
            ).allowMainThreadQueries().build()
        }
    }
}