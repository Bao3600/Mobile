package com.intellif.dblib

import android.app.Person
import android.content.Context
import com.intellif.dblib.bean.Food
import com.intellif.dblib.bean.FoodDatabase

/**
 * Created by wei.
 * Date: 2020/9/22 下午3:14
 * Description:
 */
class DBManager(context: Context) {

    private var mContext: Context = context

    companion object {
        @Volatile
        private var instance: DBManager? = null

        @Synchronized
        fun getInstance(context: Context): DBManager {
            if (instance == null) {
                instance = DBManager(context)
            }
            return instance!!
        }
    }

    fun insertFood(foodName: String, no: String, date: String): Long {
        val food = Food(foodName = foodName, Num = no, date = date)
        return FoodDatabase.getInstance(mContext).getFoodDao().insert(food)
    }

    fun update(foodName: String, no: String, date: String): Int {
        val food = Food(foodName = foodName, Num = no, date = date)
        return FoodDatabase.getInstance(mContext).getFoodDao().update(foodName,no,date)
    }

    fun deletePerson(id: Long): Int {
        return FoodDatabase.getInstance(mContext).getFoodDao().delete(id)
    }

    fun deletePerson(person: Food): Int {
        return FoodDatabase.getInstance(mContext).getFoodDao().delete(person)
    }

    fun deleteAll(): Int {
        return FoodDatabase.getInstance(mContext).getFoodDao().deleteAll()
    }

    fun countPerson(): Int? {
        return FoodDatabase.getInstance(mContext).getFoodDao().getAllFood()?.size
    }

    fun personList(): List<Food>? {
        return FoodDatabase.getInstance(mContext).getFoodDao().getAllFood()
    }
}