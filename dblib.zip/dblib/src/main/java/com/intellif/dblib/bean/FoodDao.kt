package com.intellif.dblib.bean

import androidx.room.*


/**
 * Created by wei.
 * Date: 2020/9/22 下午2:57
 * Description:
 */
@Dao
open interface FoodDao {

    @Query("SELECT * FROM Food")
    fun getAllFood(): List<Food>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(vararg food: Food): LongArray

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(foodList: List<Food>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(food: Food): Long

    @Query("UPDATE Food SET foodName = :foodName,num= :no, date = :date where date = :date")
    fun update(foodName: String, no: String, date: String): Int

    @Query("delete from food where food.id=:id")
    fun delete(id: Long): Int

    @Query("delete from food where date=:date")
    fun delete(date: String?): Int //根据条件删除

    @Delete
    fun delete(food: Food): Int //根据条件删除

    @Query("delete from food")
    fun deleteAll(): Int //删除全部信息

}