package com.intellif.dblib.bean

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Created by wei.
 * Date: 2020/9/22 下午2:45
 * Description:
 */
@Entity
class Food {
    @PrimaryKey(autoGenerate = true)
    var id: Long?
    var foodName: String?
    var Num: String? = null
    var date: String? = null

    constructor(id: Long?=null, foodName: String?, Num: String?, date: String?) {
        this.id = id
        this.foodName = foodName
        this.Num = Num
        this.date = date
    }
}